library(volesModel)

########## Simulating from full model 
set.seed(76735756)
nSteps <- 50
nObs <- 600
obsTiming <- sort(c(6 + seq(0, 12 * 44, by = 12), 9 + seq(0, 12 * 44, by = 12)))


voles_sim<-matrix(nrow=1000,ncol = 600)

for (i in 1:1000){


voleFullPrior <- function(){
  return(c(
    rnorm (1, 5, 1 )  ,       
    rnorm (1, 1, 1 )   ,      
    rexp  (1, 7 )      ,     
    rgamma(1, 4, 40 )    ,    
    rnorm (1, 15, 15 )    ,   
    rnorm (1, 0.04, 0.04 ) ,  
    rnorm (1, 1.25, 0.5 )   , 
    runif (1, 0.5, 30 )      ,
    runif (1, 20, 300 )) )      }



prior=voleFullPrior() 
r=prior[1]
e=prior[2]
g=prior[3]
h=prior[4]
a=prior[5]
d=prior[6]
s=prior[7]
sigma=prior[8]
phi=prior[9]

res <- volesSimulator(nObs = nObs, nsim = 1, nBurn = 120, model = "full", 
                      param = log(c(r = r, e = e, g = g, h = h,
                                    a = a, d = d, s = s, 
                                    sigmaProc = sigma, phi = phi)), 
                      nSteps = nSteps, T0 = 0,addObsNoise=TRUE)


# test<-res$voles[obsTiming]
voles_sim[i,]<-res$voles

}

voles_sim<-(voles_sim[!is.nan(rowSums(voles_sim)),obsTiming])
stats_sim<-matrix(nrow = nrow(voles_sim),ncol=16)
for (i in 1:nrow(voles_sim)){
stats_sim[i,]<-volesStats(voles_sim[i,],extraArgs = list("obsData"=voles_sim[i,]))
}

voles_sim[obsTiming]

# This is needed because the process is observed only in 
# the months of June and September, for 45 years
obsTiming <- sort(c(6 + seq(0, 12 * 44, by = 12), 9 + seq(0, 12 * 44, by = 12)))

# Create "synlik" object
voles_sl <- new("synlik",
                simulator = volesWrap,
                summaries = volesStats,
                param = log(c(r = 4.5, e = 1, g = 0.2, h = 0.15, a = 8,
                              d = 0.06, s = 1, sigmaProc = 1.5, phi = 100)),
                extraArgs = list("nObs" = 12 * 45,  
                                 "nBurn" = 12 * 10, 
                                 "monthsToSave" = obsTiming)
)


stats_sim<-volesStats(voles_sim,extraArgs = voles_sl@extraArgs)
















data(voles_data)
data <- round(voles_data$popDensity*10)
voles_sl@data <- round(voles_data$popDensity * 10)
voles_sl@extraArgs$obsData <- round(voles_data$popDensity * 10)
stat_obs<-volesStats(voles_data$popDensity*10,extraArgs=voles_sl@extraArgs)
stat_obs2<-volesStats(voles_data$popDensity*10,extraArgs = list("obsData"=data))


